'use strict';
const $=id=>document.getElementById(id);
const state={csrf:null, account:null, running:false, engineReady:false, engineStartedAt:null, engineLastError:null, engineLastExit:null, events:[], lastStatus:null, lastUpdated:null, config:null};
let toastTimer;
const number=v=>(typeof v==='number'&&Number.isFinite(v))?new Intl.NumberFormat('cs-CZ',{notation:v>=1000000?'compact':'standard',maximumFractionDigits:1}).format(v):'—';
const humanDate=d=>{if(!d)return '—';const n=new Date(d);return Number.isNaN(n.getTime())?'—':n.toLocaleTimeString('cs-CZ',{hour:'2-digit',minute:'2-digit'});};
function text(id,val){const e=$(id);if(e)e.textContent=val==null?'—':String(val);}
function toast(msg,error=false){const box=$('toast');box.textContent=msg;box.classList.toggle('error',error);box.classList.add('visible');clearTimeout(toastTimer);toastTimer=setTimeout(()=>box.classList.remove('visible'),5000);}
async function api(endpoint,method='GET',data){
 const options={method,credentials:'same-origin',headers:{}};
 if(method!=='GET' && method!=='HEAD'){options.headers['X-CSRF-Token']=state.csrf||'';options.headers['Content-Type']='application/json';options.body=JSON.stringify(data||{});}
 let response;try{response=await fetch('/api/'+endpoint,options);}catch{throw Error('Nelze se spojit se serverem webového panelu');}
 let v;try{v=await response.json();}catch{throw Error('Neplatná odpověď backendu');}
 if(response.status===401){showLogin();throw Error('Relace vypršela. Přihlas se znovu.');}
 if(!response.ok||v.ok===false)throw Error(v.error||'Engine vrátil chybu');
 return v;
}
function showLogin(){$('login-screen').classList.remove('hidden');state.csrf=null;}
function showApp(){$('login-screen').classList.add('hidden');}
async function safe(fn){try{await fn();}catch(e){toast(e.message||String(e),true);}}
function page(name){
 const titles={overview:['Velitelský panel','Tvoje postava. Tvoje pravidla. Ovládání z iPhonu.'],modules:['Automatizace','Nastav skutečné herní moduly.'],activity:['Historie aktivit','Události přímo ze spuštěného engine.'],settings:['Herní účet','Připojení k Mercy SF a výběr postavy.']};
 for(const el of document.querySelectorAll('.page'))el.classList.toggle('active',el.id==='page-'+name);
 for(const el of document.querySelectorAll('[data-tab]'))el.classList.toggle('selected',el.dataset.tab===name);
 text('page-title',titles[name][0]);text('page-sub',titles[name][1]);
 if(name==='modules' && state.account?.character && !state.config)safe(loadConfig);
}
function friendlyKey(key){return key.replace(/^auto_/,'').replaceAll('_',' ').replace(/\b\w/g,c=>c.toUpperCase());}
const labels={auto_quests:'Výpravy a úkoly',auto_arena:'Aréna',auto_dungeons:'Podzemí',auto_guild:'Cech',auto_pets:'Mazlíčci',auto_fortress:'Pevnost',auto_underworld:'Podsvětí',auto_scrapbook:'Album',auto_expeditions:'Expedice'};
function eventMarkup(ev){
 const item=document.createElement('div');item.className='event';
 const icon=document.createElement('div');icon.className='event-icon';icon.textContent=ev.type.includes('win')?'✦':ev.type.includes('chyba')?'!':'◈';
 const meta=document.createElement('div');meta.className='event-meta';
 const title=document.createElement('strong');title.textContent=ev.type.replaceAll('_',' ');
 const desc=document.createElement('p');desc.textContent=ev.detail||'Herní událost';meta.append(title,desc);
 const time=document.createElement('time');time.className='event-time';time.textContent=humanDate(ev.date);item.append(icon,meta,time);return item;
}
function eventsRender(id,items){const box=$(id);box.replaceChildren();if(!items.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='Zatím žádné skutečné události.';box.append(empty);}else for(const e of items)box.append(eventMarkup(e));}
function renderState(){
 const a=state.account;
 text('hero-character',a?.character||'Žádná postava');text('hero-server',a?.server||a?.username||'Přidej účet a vyber postavu');
 text('character-title',a?.character||'Nenastaveno');text('character-description',a?.username||'Přidej herní účet v Nastavení.');
 text('detail-server',a?.server||state.lastStatus?.server||'SSO účet');
 text('stat-level',number(state.lastStatus?.level));text('stat-gold',number(state.lastStatus?.silver));text('stat-mushrooms',number(state.lastStatus?.mushrooms));
 text('stat-action',state.lastStatus?.action||'—');text('stat-updated',state.lastUpdated?'Aktualizováno '+humanDate(state.lastUpdated):'Dosud nenačteno');
 text('detail-class',state.lastStatus?.class||'—');text('detail-honor',number(state.lastStatus?.honor));text('detail-rank',number(state.lastStatus?.rank));
 text('global-status',state.running?(state.engineReady?'ENGINE SPUŠTĚN':'PROCES BĚŽÍ – OVĚŘUJI'):state.account?'BOT ZASTAVEN':'NEPŘIPOJENO');
 const pill=$('global-status');pill.className='pill '+(state.running?'running':state.account?'stopped':'neutral');
 const c=$('character-running');c.textContent=state.engineReady?'ENGINE STARTED':state.running?'ČEKÁ NA START':'OFFLINE';c.classList.toggle('online',state.engineReady);
 $('start').disabled=!a?.character||state.running;$('stop').disabled=!state.running;
 text('engine-diagnostic',state.running?(state.engineReady?'✓ Engine ohlásil STARTED. Dokončení questů sleduj níže.':'⚠ Proces běží, ale zatím nepotvrdil událost STARTED. Kontroluj diagnostiku níže.'):(state.engineLastExit?'Proces skončil: '+state.engineLastExit:'Bot je zastavený.'));
 text('engine-error',state.engineLastError?'Poslední chyba: '+state.engineLastError:'');
 eventsRender('event-mini',state.events.slice(0,4));eventsRender('all-events',state.events);
}
async function poll(){
 const d=await api('state');Object.assign(state,{account:d.account,running:d.running,engineReady:d.engineReady,engineStartedAt:d.engineStartedAt,engineLastError:d.engineLastError,engineLastExit:d.engineLastExit,events:d.events,lastStatus:d.lastStatus,lastUpdated:d.lastUpdated});renderState();
}
async function loadVersion(){try{const v=await api('version');text('engine-version',v.version||'Neznámá');text('engine-short','Engine: '+(v.version||'připojen'));text('backend-status','Připojen (API '+v.api+')');}catch(e){text('engine-version','Nenalezen');text('engine-short','Engine: nepřipojeno');text('backend-status','Spusť Mercy SF CLI');}}
async function loadCharacters(){const v=await api('characters');const select=$('char-select');select.replaceChildren();
 const arr=Array.isArray(v.characters)?v.characters:[];
 if(!arr.length){const op=new Option('Nenalezeny žádné postavy','');select.add(op);return;}
 for(const char of arr){select.add(new Option(`${char.character} • ${char.server||'SSO'} • lvl ${char.level??'?'}`,char.character));}
 if(state.account?.character && arr.some(c=>c.character===state.account.character))select.value=state.account.character;
 toast('Načteny postavy: '+arr.length);
}
async function loadStatus(){const v=await api('status');state.lastStatus=v.status;state.lastUpdated=v.at;renderState();toast('Data postavy byla načtena z hry');}
async function loadConfig(){
 const v=await api('config');state.config=v;
 const flags=(Array.isArray(v.settable)?v.settable:[]).filter(k=>/^auto_[a-z0-9_]+$/.test(k));
 const root=$('modules');root.replaceChildren();
 if(!flags.length){const empty=document.createElement('div');empty.className='empty';empty.textContent='Engine nevrátil žádné upravitelné automatizační přepínače.';root.append(empty);return;}
 for(const flag of flags){
  const item=document.createElement('div');item.className='module';
  const title=document.createElement('div');const b=document.createElement('div');b.className='module-title';b.textContent=labels[flag]||friendlyKey(flag);const sub=document.createElement('div');sub.className='module-sub';sub.textContent=flag;title.append(b,sub);
  const label=document.createElement('label');label.className='switch';label.setAttribute('aria-label',b.textContent);
  const input=document.createElement('input');input.type='checkbox';input.checked=v.config?.[flag]===true;
  const slider=document.createElement('span');slider.className='slider';label.append(input,slider);
  input.addEventListener('change',async()=>{input.disabled=true;try{await api('config','POST',{key:flag,enabled:input.checked});toast('Nastavení uloženo: '+b.textContent);}catch(e){input.checked=!input.checked;toast(e.message,true);}finally{input.disabled=false;}});
  item.append(title,label);root.append(item);
 }
}
async function login(e){e.preventDefault();const pass=$('admin-password').value;const box=$('login-error');box.textContent='';
 try{const r=await fetch('/api/login',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({password:pass})});const v=await r.json();if(!r.ok)throw Error(v.error||'Nelze se přihlásit');state.csrf=v.csrf;$('admin-password').value='';showApp();await poll();await loadVersion();toast('Přihlášení úspěšné');}catch(e){box.textContent=e.message;}
}
$('login-form').addEventListener('submit',login);
$('account-form').addEventListener('submit',e=>{e.preventDefault();safe(async()=>{await api('account','POST',{username:$('game-user').value,password:$('game-password').value,server:$('game-server').value});$('game-password').value='';state.config=null;await poll();toast('Účet byl zašifrovaně uložen. Teď načti postavy.');});});
$('logout').addEventListener('click',()=>safe(async()=>{await api('logout','POST');showLogin();}));
$('delete-account').addEventListener('click',()=>{if(!confirm('Opravdu odstranit herní účet a uložené přihlašovací údaje?'))return;safe(async()=>{await api('account','DELETE');state.config=null;await poll();toast('Účet odstraněn');});});
$('list-chars').addEventListener('click',()=>safe(loadCharacters));
$('save-char').addEventListener('click',()=>safe(async()=>{await api('character','POST',{character:$('char-select').value});state.config=null;await poll();toast('Postava vybrána');}));
$('start').addEventListener('click',()=>safe(async()=>{await api('start','POST');await poll();toast('Engine obdržel příkaz ke spuštění');}));
$('stop').addEventListener('click',()=>safe(async()=>{await api('stop','POST');await poll();toast('Engine dostal příkaz k bezpečnému zastavení');}));
$('refresh-status').addEventListener('click',()=>safe(loadStatus));
$('refresh-config').addEventListener('click',()=>safe(loadConfig));
$('refresh-events').addEventListener('click',()=>safe(poll));
for(const b of document.querySelectorAll('[data-tab]'))b.addEventListener('click',()=>page(b.dataset.tab));
for(const b of document.querySelectorAll('[data-goto]'))b.addEventListener('click',()=>page(b.dataset.goto));
function clock(){text('clock',new Date().toLocaleString('cs-CZ',{day:'2-digit',month:'long',hour:'2-digit',minute:'2-digit'}));}
clock();setInterval(clock,60000);
(async()=>{try{const v=await api('session');state.csrf=v.csrf;showApp();await poll();await loadVersion();}catch{showLogin();}})();
setInterval(()=>{if(state.csrf && !document.hidden)poll().catch(()=>{});},15000);
