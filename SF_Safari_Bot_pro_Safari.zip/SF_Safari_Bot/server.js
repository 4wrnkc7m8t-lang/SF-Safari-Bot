'use strict';
/*
 * SF Safari Bot Panel – original Node.js control panel, not an S&F game client.
 * The game automation is performed by a separate, official Mercy SF CLI binary.
 * This project is independent and not affiliated with Mercy SF or Playa Games.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {spawn} = require('node:child_process');

const HOST = process.env.HOST || '127.0.0.1';
const PORT = Number(process.env.PORT || '3030');
const DATA = process.env.DATA_DIR || path.join(__dirname, 'data');
const PUBLIC = path.join(__dirname, 'public');
const CLI = process.env.MERCY_CLI || 'mercy-cli';
const PASSWORD = process.env.DASHBOARD_PASSWORD;
const COOKIE = 'sf_safari_session';
const sessions = new Map(), failures = new Map();
const events = [];
let account = null, proc = null, lastStatus = null, lastUpdated = null, sessionId = null;

if (!PASSWORD || PASSWORD.length < 12) {
  process.stderr.write('CHYBA: nastav DASHBOARD_PASSWORD (aspoň 12 znaků).\n');
  process.exit(1);
}
if (HOST !== '127.0.0.1' && HOST !== '::1' && !process.env.ALLOW_REMOTE_BIND) {
  process.stderr.write('CHYBA: vzdálené naslouchání vyžaduje ALLOW_REMOTE_BIND=1 a HTTPS reverzní proxy / soukromou VPN.\n');
  process.exit(1);
}
fs.mkdirSync(DATA, {recursive:true, mode:0o700});
try {fs.chmodSync(DATA,0o700);}catch{}
const SECRET_PATH = path.join(DATA,'key.bin');
let key;
if (process.env.BOT_ENCRYPTION_KEY) {
  key = Buffer.from(process.env.BOT_ENCRYPTION_KEY, 'hex');
  if (key.length !== 32) throw Error('BOT_ENCRYPTION_KEY musí být 64 hex znaků');
} else if (fs.existsSync(SECRET_PATH)) {
  key = fs.readFileSync(SECRET_PATH);
  if (key.length !== 32) throw Error('Chybný lokální šifrovací klíč');
} else {
  key = crypto.randomBytes(32);
  fs.writeFileSync(SECRET_PATH,key,{flag:'wx',mode:0o600});
}
const accountPath = path.join(DATA,'account.json');
try {account = JSON.parse(fs.readFileSync(accountPath,'utf8'));}catch(e){if(e.code!=='ENOENT') throw e;}
const pwHash = crypto.scryptSync(PASSWORD,'sf-safari-admin-v1',64);

function encrypt(secret) {
  const iv=crypto.randomBytes(12), cipher=crypto.createCipheriv('aes-256-gcm',key,iv);
  const enc=Buffer.concat([cipher.update(secret,'utf8'),cipher.final()]);
  return [iv.toString('hex'),cipher.getAuthTag().toString('hex'),enc.toString('hex')].join(':');
}
function decrypt(data) {
  const [i,t,c]=data.split(':');
  const d=crypto.createDecipheriv('aes-256-gcm',key,Buffer.from(i,'hex'));
  d.setAuthTag(Buffer.from(t,'hex'));
  return Buffer.concat([d.update(Buffer.from(c,'hex')),d.final()]).toString('utf8');
}
function saveAccount(){
  const target = accountPath + '.tmp';
  fs.writeFileSync(target,JSON.stringify(account,null,2),{mode:0o600});
  fs.renameSync(target,accountPath);
}
function addEvent(type,detail='') {
  events.unshift({date:new Date().toISOString(),type, detail:String(detail).slice(0,250)});
  if(events.length>150)events.length=150;
}
function json(res, code, obj, more={}){
  res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...more});
  res.end(JSON.stringify(obj));
}
function security(res){
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('X-Frame-Options','DENY');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()');
  res.setHeader('Content-Security-Policy',"default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'");
}
function parseCookies(req){const out={};for(const entry of (req.headers.cookie||'').split(';')){const i=entry.indexOf('=');if(i>0)out[entry.slice(0,i).trim()]=entry.slice(i+1).trim();}return out;}
function auth(req){
  const token=parseCookies(req)[COOKIE];
  const s=token && sessions.get(token);
  if(!s) return null;
  if(s.until < Date.now()){sessions.delete(token);return null;}
  return s;
}
function cookie(req,value,maxAge){
  const secure=(req.socket.encrypted || (process.env.TRUST_PROXY==='1' && req.headers['x-forwarded-proto']==='https')) ? '; Secure' : '';
  return `${COOKIE}=${value}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${maxAge}${secure}`;
}
function guardOrigin(req){
  const origin=req.headers.origin;
  if(!origin)return true; // non-browser clients still require session and CSRF
  try {const u=new URL(origin); return u.host===req.headers.host && (u.protocol==='https:'||u.protocol==='http:');}catch{return false;}
}
async function body(req){
  let text='';
  for await(const c of req){text+=c;if(text.length>20000)throw Error('Příliš velký požadavek');}
  try{return text?JSON.parse(text):{};}catch{throw Error('Nesprávný JSON');}
}
function validateAccount(a){
  if(typeof a.username!=='string'||a.username.length<2||a.username.length>180) throw Error('Zadej uživatelské jméno účtu');
  if(typeof a.password!=='string'||a.password.length<1||a.password.length>500)throw Error('Zadej heslo herního účtu');
  if(a.server){
    let u;try{u=new URL(a.server);}catch{throw Error('Nesprávná URL serveru');}
    if(u.protocol!=='https:'||u.username||u.password)throw Error('Server musí být https:// bez přihlašovacích údajů v URL');
    if(['localhost','127.0.0.1','::1'].includes(u.hostname)||u.hostname.endsWith('.local'))throw Error('Místní adresa serveru není povolená');
  }
}
function cliArgs(args){return [...args,'--user',account.username,...(account.server?['--server',account.server]:[]),'--password-stdin'];}
function engineEnv(){const env={...process.env};delete env.DASHBOARD_PASSWORD;delete env.BOT_ENCRYPTION_KEY;delete env.MERCY_SF_PASSWORD;return env;}
function runCli(args,options={}){
  return new Promise((resolve,reject)=>{
    if(!account && options.password!==false) return reject(Error('Nejdřív přidej herní účet'));
    let child;
    try{child=spawn(CLI, options.password===false?args:cliArgs(args), {stdio:['pipe','pipe','pipe'],env:engineEnv(),shell:false});}
    catch(e){return reject(e);}
    let output='',err='',done=false;
    const timer=setTimeout(()=>{child.kill('SIGTERM');finish(Error('Časový limit engine – zkus to později'));},45000);
    function finish(error,value){if(done)return;done=true;clearTimeout(timer);if(error)reject(error);else resolve(value);}
    child.on('error',e=>finish(Error('Herní engine nenalezen nebo jej nelze spustit: '+e.message)));
    child.stdout.on('data',b=>{output+=b.toString();if(output.length>200000)child.kill('SIGTERM');});
    child.stderr.on('data',b=>{err=(err+b.toString()).slice(-1500);});
    child.on('close',(code)=>{
      if(done)return;
      try{
        const val=JSON.parse(output.trim());
        if(code!==0||val.ok===false)finish(Error(val.error||'Mercy SF vrátil chybu'));
        else finish(null,val);
      }catch{finish(Error('CLI neposlal platnou JSON odpověď'+(err?': '+err.slice(-180):'')));}
    });
    if(options.password===false) child.stdin.end();
    else child.stdin.end(decrypt(account.secret)+'\n');
  });
}
function active(){return proc!==null && proc.exitCode===null && !proc.killed;}
function publicState(){return {running:active(), account:account?{username:account.username,server:account.server||'',character:account.character||''}:null,lastStatus,lastUpdated,events:events.slice(0,60)};}
function startEngine(){
  if(active()) throw Error('Bot už běží');
  if(!account?.character)throw Error('Nejdřív vyber postavu');
  const a=cliArgs(['--start','--character',account.character,'--events']);
  proc=spawn(CLI,a,{stdio:['pipe','pipe','pipe'],shell:false,env:engineEnv()});
  const current=proc;
  let stream='';
  current.on('error',e=>addEvent('chyba','Nepodařilo se spustit engine: '+e.message));
  current.stdout.on('data',b=>{
    stream+=b.toString();
    if(stream.length>25000)stream=stream.slice(-12000);
    for(;;){const i=stream.indexOf('\n');if(i<0)break;const line=stream.slice(0,i);stream=stream.slice(i+1);
      try{const event=JSON.parse(line);addEvent(event.event||'událost',event.character||event.reason||event.count||'');}
      catch{if(line.trim())addEvent('log',line.slice(0,120));}}
  });
  current.stderr.on('data',b=>addEvent('engine','Diagnostika: '+b.toString().slice(0,120)));
  current.on('close',(code,signal)=>{addEvent('zastaveno',`Engine skončil (kód ${code??'–'}, signál ${signal||'–'})`);if(proc===current)proc=null;});
  current.stdin.end(decrypt(account.secret)+'\n');
  addEvent('spuštění','Byl zadán příkaz ke spuštění '+account.character);
}
async function route(req,res){
  security(res);
  const url = new URL(req.url,'http://localhost');
  if(!url.pathname.startsWith('/api/')){
    if(req.method!=='GET'&&req.method!=='HEAD')return json(res,405,{error:'Nepovolená metoda'});
    const names={'/':'index.html','/index.html':'index.html','/app.js':'app.js','/style.css':'style.css','/manifest.webmanifest':'manifest.webmanifest'};
    const name=names[url.pathname];if(!name)return json(res,404,{error:'Soubor nenalezen'});
    const types={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.webmanifest':'application/manifest+json; charset=utf-8'};
    res.writeHead(200,{'Content-Type':types[path.extname(name)],'Cache-Control':'no-store'});
    return fs.createReadStream(path.join(PUBLIC,name)).pipe(res);
  }
  if(!['GET','HEAD'].includes(req.method)&&!guardOrigin(req))return json(res,403,{error:'Odmítnutý původ požadavku'});
  if(url.pathname==='/api/login' && req.method==='POST'){
    const ip=req.socket.remoteAddress||'unknown';
    const record=failures.get(ip)||{count:0,reset:0};
    if(Date.now()>record.reset){record.count=0;record.reset=Date.now()+15*60*1000;}
    if(record.count>=8)return json(res,429,{error:'Příliš mnoho pokusů. Zkus to později.'});
    const data=await body(req);
    const actual=crypto.scryptSync(String(data.password||''),'sf-safari-admin-v1',64);
    if(!crypto.timingSafeEqual(pwHash,actual)){
      record.count++; failures.set(ip,record);return json(res,401,{error:'Nesprávné heslo k panelu'});
    }
    failures.delete(ip);
    const token=crypto.randomBytes(32).toString('hex');
    const sess={until:Date.now()+12*60*60*1000, csrf:crypto.randomBytes(24).toString('hex')};
    sessions.set(token,sess);
    return json(res,200,{ok:true,csrf:sess.csrf},{'Set-Cookie':cookie(req,token,12*60*60)});
  }
  const s=auth(req);
  if(!s)return json(res,401,{error:'Nejdřív se přihlas do panelu'});
  if(!['GET','HEAD'].includes(req.method) && req.headers['x-csrf-token']!==s.csrf)return json(res,403,{error:'Chybí bezpečnostní token'});
  if(url.pathname==='/api/session'&&req.method==='GET')return json(res,200,{ok:true,csrf:s.csrf});
  if(url.pathname==='/api/logout'&&req.method==='POST'){
    const token=parseCookies(req)[COOKIE];sessions.delete(token);
    return json(res,200,{ok:true},{'Set-Cookie':cookie(req,'',0)});
  }
  if(url.pathname==='/api/state'&&req.method==='GET')return json(res,200,{ok:true,...publicState()});
  if(url.pathname==='/api/account'&&req.method==='POST'){
    if(active())throw Error('Nejdřív zastav bota');
    const v=await body(req);validateAccount(v);
    account={username:v.username.trim(),server:(v.server||'').trim(),secret:encrypt(v.password),character:''};
    lastStatus=null;saveAccount();addEvent('účet','Uložen herní účet');
    return json(res,200,{ok:true,account:publicState().account});
  }
  if(url.pathname==='/api/account'&&req.method==='DELETE'){
    if(active())throw Error('Nejdřív zastav bota');
    account=null;lastStatus=null;
    try{fs.unlinkSync(accountPath);}catch(e){if(e.code!=='ENOENT')throw e;}
    return json(res,200,{ok:true});
  }
  if(url.pathname==='/api/character'&&req.method==='POST'){
    if(active())throw Error('Během hraní nemůžeš měnit postavu');
    const v=await body(req);
    if(typeof v.character!=='string'||v.character.length>100||!v.character.trim())throw Error('Vyber platnou postavu');
    if(!account)throw Error('Nejdřív přidej účet');
    account.character=v.character.trim();saveAccount();lastStatus=null;
    return json(res,200,{ok:true});
  }
  if(url.pathname==='/api/version'&&req.method==='GET'){
    const data=await runCli(['--version'],{password:false});
    return json(res,200,{ok:true,version:data.version,api:data.api});
  }
  if(url.pathname==='/api/characters'&&req.method==='GET')return json(res,200,await runCli(['--characters']));
  if(url.pathname==='/api/status'&&req.method==='GET'){
    if(!account?.character)throw Error('Nejdřív vyber postavu');
    lastStatus=await runCli(['--status','--character',account.character]);
    lastUpdated=new Date().toISOString();
    return json(res,200,{ok:true,status:lastStatus,at:lastUpdated});
  }
  if(url.pathname==='/api/config'&&req.method==='GET'){
    if(!account?.character)throw Error('Nejdřív vyber postavu');
    const v=await runCli(['--config','--character',account.character]);
    return json(res,200,v);
  }
  if(url.pathname==='/api/config'&&req.method==='POST'){
    if(!account?.character)throw Error('Nejdřív vyber postavu');
    const v=await body(req);
    if(typeof v.key!=='string'||!/^auto_[a-z0-9_]+$/.test(v.key)||typeof v.enabled!=='boolean')throw Error('Povolené jsou pouze automatizační přepínače');
    const cfg=await runCli(['--config','--character',account.character]);
    if(!Array.isArray(cfg.settable)||!cfg.settable.includes(v.key))throw Error('Tento přepínač engine nepovoluje měnit');
    const changed=await runCli(['--config','--character',account.character,'--set',v.key+'='+v.enabled]);
    addEvent('nastavení',v.key+' = '+v.enabled);return json(res,200,changed);
  }
  if(url.pathname==='/api/start'&&req.method==='POST'){
    if(active())throw Error('Bot už běží');
    // Confirm binary exists before accepting the start request.
    const version=await runCli(['--version'],{password:false});
    if(version.api!==1)throw Error('Nepodporovaná verze API Mercy SF');
    startEngine();return json(res,200,{ok:true,starting:true});
  }
  if(url.pathname==='/api/stop'&&req.method==='POST'){
    if(!active())throw Error('Bot neběží');
    proc.kill('SIGTERM'); addEvent('zastavování','Příkaz k bezpečnému ukončení');
    return json(res,200,{ok:true,stopping:true});
  }
  if(url.pathname==='/api/claim'&&req.method==='POST'){
    if(!account?.character)throw Error('Nejdřív vyber postavu');
    const v=await runCli(['--claim','--character',account.character]);
    addEvent('odměny','Vyžádáno převzetí odměn');return json(res,200,v);
  }
  if(url.pathname==='/api/events'&&req.method==='GET')return json(res,200,{ok:true,events:events.slice(0,100)});
  return json(res,404,{error:'Nenalezeno'});
}
const server=http.createServer((req,res)=>route(req,res).catch(e=>json(res,400,{error:e.message||'Neznámá chyba'})));
server.listen(PORT,HOST,()=>console.log(`SF Safari Panel: http://${HOST}:${PORT} (Mercy CLI: ${CLI})`));
function shutdown(){if(proc&&proc.exitCode===null)proc.kill('SIGTERM');server.close();}
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
