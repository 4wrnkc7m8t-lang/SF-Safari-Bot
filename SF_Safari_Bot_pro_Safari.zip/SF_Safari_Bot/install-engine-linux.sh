#!/usr/bin/env bash
# Stáhne originální Mercy SF CLI pro Ubuntu/Debian a ověří jeho SHA-256.
# Nepoužívej pro veřejné nasazení bez HTTPS/VPN.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/bin"
case "$(uname -m)" in
 x86_64|amd64) ART='mercy-cli-linux-x64';;
 aarch64|arm64) ART='mercy-cli-linux-arm64';;
 *) echo 'Nepodporovaná architektura, pouze x86_64/arm64' >&2; exit 1;;
esac
command -v curl >/dev/null || { echo 'Nainstaluj curl' >&2; exit 1; }
command -v sha256sum >/dev/null || { echo 'Nainstaluj coreutils' >&2; exit 1; }
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
curl -fSL --retry 3 "https://mercysf.app/downloads/$ART" -o "$TMP/$ART"
curl -fSL --retry 3 https://mercysf.app/downloads/SHA256SUMS.txt -o "$TMP/SHA256SUMS.txt"
(cd "$TMP" && sha256sum -c SHA256SUMS.txt --ignore-missing | grep -Fx "$ART: OK") || {
 echo 'CHYBA: kontrolní součet CLI neodpovídá oficiálnímu manifestu. Instalace zastavena.' >&2; exit 1;
}
install -m 700 "$TMP/$ART" "$ROOT/bin/mercy-cli"
"$ROOT/bin/mercy-cli" --version
printf '\nEngine nainstalován do %s/bin/mercy-cli\n' "$ROOT"
