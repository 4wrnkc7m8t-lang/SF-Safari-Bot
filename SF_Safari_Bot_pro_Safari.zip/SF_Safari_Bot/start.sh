#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$(realpath "$0")")"
if ! command -v node >/dev/null; then echo 'Chyba: nainstaluj Node.js 20+' >&2; exit 1; fi
if [[ -z "${DASHBOARD_PASSWORD:-}" ]]; then echo 'Nastav DASHBOARD_PASSWORD (12+ znaků), viz README_CZ.md' >&2; exit 1; fi
exec node server.js
