#!/usr/bin/env node
// Mock pro testy serverové integrace. Neodesílá žádné požadavky do hry.
const args=process.argv.slice(2);
if(args.includes('--version')){console.log(JSON.stringify({ok:true,version:'2.27-test',api:1}));process.exit(0);}
function respond(){
 const char=args.includes('--character')?args[args.indexOf('--character')+1]:'Hero';
 if(args.includes('--characters'))return {ok:true,characters:[{character:'Hero',server:'https://s1.sfgame.net/',level:123}]};
 if(args.includes('--status'))return {ok:true,character:char,server:'https://s1.sfgame.net/',level:123,class:'Warrior',silver:9950,mushrooms:20,honor:300,rank:400,action:'CityGuard'};
 if(args.includes('--config')){
  if(args.includes('--set'))return {ok:true,settable:['auto_arena','auto_quests'],changed:[{key:args[args.indexOf('--set')+1]}]};
  return {ok:true,config:{auto_arena:true,auto_quests:false,secret_override:true},settable:['auto_arena','auto_quests']};
 }
 if(args.includes('--claim'))return {ok:true,claimed:1};
 return {ok:false,error:'Unknown command'};
}
let input='';
process.stdin.on('data',d=>input+=d.toString());
process.stdin.on('end',()=>{
 if(input.trim()!=='game-test-password'){console.log(JSON.stringify({ok:false,error:'password mismatch'}));return process.exit(1);}
 if(args.includes('--start')){
  process.stdout.write(JSON.stringify({at:new Date().toISOString(),api:1,event:'started',character:'Hero'})+'\n');
  setInterval(()=>{},1000);
 } else console.log(JSON.stringify(respond()));
});
process.on('SIGTERM',()=>{process.stdout.write(JSON.stringify({at:new Date().toISOString(),api:1,event:'stopped',character:'Hero'})+'\n');process.exit(0);});
