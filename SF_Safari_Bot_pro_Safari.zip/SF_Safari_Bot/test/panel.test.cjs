'use strict';
const {test,after} = require('node:test');
const assert=require('node:assert/strict');
const {spawn}=require('node:child_process');
const path=require('node:path');
const fs=require('node:fs');
const os=require('node:os');
const net=require('node:net');
const base=path.join(__dirname,'..');
const data=fs.mkdtempSync(path.join(os.tmpdir(),'sf-safari-'));
let server,cookie,csrf,url;
after(()=>{server?.kill('SIGTERM');fs.rmSync(data,{recursive:true,force:true});});
async function fetchJSON(route,method='GET',data,custom={}){
 const r=await fetch(url+route,{method,headers:{...(data?{'content-type':'application/json'}:{}),...(csrf?{'x-csrf-token':csrf}:{}),...(cookie?{'cookie':cookie}:{}),...custom},body:data?JSON.stringify(data):undefined});
 const v=await r.json();return {status:r.status,data:v,headers:r.headers};
}
test('plnohodnotné ověření API proti fiktivnímu CLI',async()=>{
 const temp=net.createServer();await new Promise(r=>temp.listen(0,'127.0.0.1',r));
 const port=temp.address().port;await new Promise(r=>temp.close(r));
 url='http://127.0.0.1:'+port;
 server=spawn(process.execPath,[path.join(base,'server.js')],{env:{...process.env,DATA_DIR:data,HOST:'127.0.0.1',PORT:String(port),DASHBOARD_PASSWORD:'123456789012Strong!',MERCY_CLI:path.join(base,'test','fake-cli.cjs')},stdio:['ignore','pipe','pipe']});
 let output='';server.stderr.on('data',d=>{output+=d.toString();});
 let started=false;
 for(let i=0;i<90;i++){
   try{const x=await fetch(url);if(x.ok){started=true;break;}}catch{}
   await new Promise(r=>setTimeout(r,75));
 }
 assert.equal(started,true,'server failed to start: '+output);
 assert.equal((await fetchJSON('/api/state')).status,401,'API has to require login');
 assert.equal((await fetchJSON('/api/login','POST',{password:'wrong'})).status,401);
 const login=await fetchJSON('/api/login','POST',{password:'123456789012Strong!'});
 assert.equal(login.status,200);csrf=login.data.csrf;
 cookie=login.headers.get('set-cookie').split(';')[0];
 assert.equal((await fetchJSON('/api/state')).status,200);
 assert.equal((await fetchJSON('/api/version')).data.api,1);
 assert.equal((await fetchJSON('/api/account','POST',{username:'player@example.com',password:'game-test-password'})).status,200);
 assert.equal((await fetchJSON('/api/characters')).data.characters[0].character,'Hero');
 assert.equal((await fetchJSON('/api/character','POST',{character:'Hero'})).status,200);
 assert.equal((await fetchJSON('/api/status')).data.status.level,123);
 const config=await fetchJSON('/api/config');assert.equal(config.data.config.auto_arena,true);
 assert.equal((await fetchJSON('/api/config','POST',{key:'secret_override',enabled:false})).status,400);
 assert.equal((await fetchJSON('/api/config','POST',{key:'auto_arena',enabled:false})).status,200);
 assert.equal((await fetchJSON('/api/claim','POST')).status,200);
 assert.equal((await fetchJSON('/api/start','POST')).status,200);
 await new Promise(r=>setTimeout(r,200));
 assert.equal((await fetchJSON('/api/state')).data.running,true);
 assert.equal((await fetchJSON('/api/stop','POST')).status,200);
 await new Promise(r=>setTimeout(r,200));
 const current=await fetchJSON('/api/state');
 assert.equal(current.data.running,false);
 assert.ok(current.data.events.some(e=>e.type==='started'));
 assert.ok(current.data.events.some(e=>e.type==='stopped'));
 const stored=fs.readFileSync(path.join(data,'account.json'),'utf8');
 assert.ok(!stored.includes('game-test-password'),'secret should not be stored unencrypted');
 assert.equal((await fetchJSON('/api/logout','POST')).status,200);
 assert.equal((await fetchJSON('/api/state')).status,401);
});
