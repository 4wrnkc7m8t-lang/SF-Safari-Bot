# SF Safari Bot – skutečný český webový panel

**Co funguje:** vlastní přihlášení do panelu, šifrované uložení údajů k hernímu účtu, načtení seznamu postav ze skutečného Mercy SF CLI, načtení herních statistik, Start / Stop skutečného herního procesu, události procesu a přepínání povolených `auto_*` nastavení. Žádná falešná herní data, žádný demo bot. Rozhraní je uzpůsobeno pro Safari a lze jej přidat na domovskou obrazovku iPhonu.

**Co není možné:** Aby samotný Mercy SF engine běžel uvnitř stránky Safari na iPhonu po jejím zavření. Safari neumí provozovat dodanou nativní CLI aplikaci, pozadí prohlížeče se uspává. Engine musí běžet na serveru/PC a Safari je pouze ovladač.

## A) Lokální rychlý test

Potřebuješ **Node.js 20+** (nic dalšího přes `npm install` není potřeba).

1. Rozbal ZIP.
2. Na Linuxu můžeš spustit `./install-engine-linux.sh`. Stáhne se **oficiální Mercy SF CLI** a ověří se kontrolní součet vůči aktuálnímu manifestu výrobce. Pokud vydavatel právě vydal binárku a manifest ještě nebyl aktualizován, instalátor raději skončí chybou. Jinak můžeš nainstalovat CLI ručně z https://mercysf.app/downloads.
3. Spusť v terminálu v rozbalené složce:

   ```bash
   DASHBOARD_PASSWORD='NastavVelmiSilneHeslo123!' MERCY_CLI=./bin/mercy-cli node server.js
   ```

4. Otevři `http://127.0.0.1:3030` ve stejném počítači. Přihlas se heslem z `DASHBOARD_PASSWORD`. Na iPhonu v jiné síti tato lokální adresa fungovat nebude.
5. V záložce „Účet“ zadej údaje, načti postavy, vyber postavu. Pak klikni na „Spustit bota“.

Veškerá automatizace používá **originální Mercy SF CLI**. Pokud `mercy-cli` není nainstalované, stránka se otevře, ale ukáže „Engine nenalezen“. Tlačítka na skutečné akce nepředstírají úspěch.

## B) Safari odkudkoliv

Umísti panel na vlastní VPS s Node.js 20+ a Mercy SF CLI. **Nevystavuj port `3030` přímo do veřejného internetu.** Naslouchej na `127.0.0.1:3030` a použij zabezpečený přístup přes Tailscale (soukromá VPN) nebo HTTPS reverse proxy s certifikátem. Přístup pak přes HTTPS URL v Safari. Pro přístup z iPhonu přes VPN je potřeba zvolit správný postup sdílení služby z VPS. Nekopíruj sem ani do veřejných úložišť soubor `data/key.bin` či `data/account.json`.

- Po ověření spojení můžeš v Safari zvolit **Sdílet → Přidat na plochu** a panel pak otevírat jako webovou aplikaci.
- Na podporovaném hostingu můžeš z tohoto projektu sestavit `Dockerfile`: oficiální binárka se stáhne při sestavení, před použitím se kontroluje SHA-256 a poté se spustí náš český panel. Nastav tajnou proměnnou `DASHBOARD_PASSWORD` a **trvalý disk pro `/app/data`**, jinak by se po restartu mohly ztratit účty. Vyber hosting, který drží proces aktivní a zajišťuje HTTPS; statický hosting nestačí.
- Pro nepřetržitý provoz musí být server zapnutý. Samotné zavření Safari botovi nevadí, pokud má server spuštěný proces `node server.js` a běžící Mercy SF CLI.
- Doporučeno provozovat `node server.js` pod systemd s restartem služby na výpadek. **Pozor:** po restartu webového panelu se aktuální bot nespustí automaticky; znovu klikni Start (úmyslné, bezpečné chování).
- Uživatelské jméno a herní heslo zadávej pouze na tvém serveru, nikdy do chatu.

## Nastavení serveru

| Proměnná | K čemu slouží |
|--|--|
| `DASHBOARD_PASSWORD` | Povinné heslo panelu, 12+ znaků |
| `MERCY_CLI` | Přesná cesta k nainstalované oficiální binárce |
| `HOST` | Výchozí `127.0.0.1` |
| `PORT` | Výchozí `3030` |
| `DATA_DIR` | Výchozí `./data` |
| `BOT_ENCRYPTION_KEY` | Volitelný klíč: 64 hex znaků; jinak vznikne v `data/key.bin` |
| `ALLOW_REMOTE_BIND` | Nutné `1` při použití HOST mimo localhost; pouze v bezpečné síti |
| `TRUST_PROXY` | `1` pouze za důvěryhodnou HTTPS proxy (Secure session cookies) |

Herní heslo se ukládá přes AES-256-GCM na místním úložišti. Šifrovací klíč má nastavená oprávnění pro vlastníka. Pro skutečný internetový provoz provozuj pod samostatným neprivilegovaným uživatelem a s TLS (HTTPS) – tento balíček není hotové veřejné SaaS.

## Technické omezení a férové upozornění

- `mercy-cli` je samostatná aplikace SenseiIssei / Mercy SF; není součástí ZIPu (originální binárku si stáhneš z oficiálního webu). Kód herního enginu nekopírujeme a nepřevádíme do JavaScriptu.
- Události v panelu jsou od posledního spuštění webové služby; data herní postavy se načtou pouze při kliknutí na „Načíst skutečná data“, aby každé otevření Safari nepřidávalo nové přihlášení do hry.
- Neobsahuje automatické utrácení houbiček; další konkrétní možnosti určuje Mercy SF konfigurace. Zkontroluj v Mercy SF, že funkce placení za houbičky máš vypnuté.
- Automatizované hraní je podle pravidel hry rizikové a může způsobit ban účtu.
- Vyvinuto nezávisle. Využívá dokumentované veřejné CLI Mercy SF: https://mercysf.app/docs/guide/cli-api. Repo stávajícího AGPL dashboardu: https://github.com/dandulox/MercySF_Dashboard. Kód tohoto originálního panelu není kopií AGPL projektu.

## Kontrolní testy

Spusť `npm test` – testovací skript používá zástupný lokální engine, neherní přihlašovací údaje a ověřuje propojení endpointů, přihlašování, odmítnutí nepovoleného přepínače a spuštění/zastavení procesu. **To není důkaz úspěšného přihlášení do skutečné hry**, to lze ověřit teprve po připojení tvého účtu.
